#!/usr/bin/env bash
# Run from the repo root after copying this folder's files over it. Makes scripts portable and commits test BAMs.
set -euo pipefail
for f in scripts/call_one.sh scripts/call_variants.sh scripts/evaluate.sh scripts/get_truth.sh scripts/make_fastq.sh scripts/align.sh; do
  sed -i 's#^cd ~/giab-sequencer-bakeoff#cd "$(dirname "$0")/.."#' $f
done
# call_one.sh needs the region file the Snakefile never creates
grep -q 'printf "chr20' scripts/call_one.sh || sed -i '/^mkdir -p results\/timing/a [ -s data/region.bed ] || printf "chr20\\t10000000\\t15000000\\n" > data/region.bed' scripts/call_one.sh
# .gitignore blocks *.bam/*.bai, so the 200 kb test BAMs were never pushed: allow them
grep -q '!test_data' .gitignore || printf '!test_data/*.bam\n!test_data/*.bam.bai\n' >> .gitignore
echo "now: git add -f test_data && git status"
