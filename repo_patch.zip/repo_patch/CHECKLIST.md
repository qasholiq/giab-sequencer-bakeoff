# What was missing in the repo (found by auditing against the handbook)

| Gap | Handbook criterion | Status after patch |
|---|---|---|
| test_data/*.bam never pushed (.gitignore blocks *.bam/*.bai) so `run_test.sh` fails on a clean clone | Reproducibility (4) | apply_fixes.sh adds `!test_data/*.bam`; then `git add -f test_data` |
| README had `<FETCH_SCRIPT>`, `<N>` placeholders; no reference fetch script | Reproducibility | README.md + scripts/get_reference.sh |
| No script for the remote slicing (done by hand) | Database work: retrieval scripted (8) | scripts/get_slices.sh |
| results/qc/ is empty: no FastQC/fastp/NanoPlot output anywhere | NGS QC (7), TGS handling (7) | scripts/qc.sh. MUST be run, numbers pasted into report 4.2/4.3 |
| Scripts hard-code `cd ~/giab-sequencer-bakeoff`; call_one.sh needs data/region.bed that Snakefile never makes | Reproducibility | apply_fixes.sh |
| predictions.md "To fill after analysis" empty | Results (6) | docs/predictions_scorecard.md (append to predictions.md) |
| P9 cost per correct variant never computed | Task 8 | scripts/cost_per_variant.py |
| No CIs; no report in repo; report/ only has .gitkeep | Results, Report | scripts/make_report_figures.py; report/ |
| envs/happy.yml, bake.yml unused/unlocked (conda export without pins for Snakemake) | Reproducibility | mention in README; optional |
| Snakefile has no rules for alignment, QC or aligner swap | Engineering | optional: add `align` and `qc` rules |
